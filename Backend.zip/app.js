const express = require('express');
const cors = require('cors');
const app = express();
const path = require('path');
const http = require("http");

require('dotenv').config();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const mainRoutes = require('./routes/main.routes');

app.use('/api/main', mainRoutes);

app.get('/', (req, res) => {
  res.send('Excel-data API is running...');
});

const server = http.createServer(app);

const PORT = process.env.PORT || 8060;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
