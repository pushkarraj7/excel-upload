import axios from "axios";

/**
 * Axios instance
 */
const apiClient = axios.create({
  baseURL: "", // Using relative URLs (/api)
  timeout: 15000,
  headers: {
    "Content-Type": "application/json",
  },
});

/**
 * REQUEST INTERCEPTOR
 * (Auth token, logging, etc.)
 */
apiClient.interceptors.request.use(
  (config) => {
    // Example: attach token later
    // const token = localStorage.getItem("token");
    // if (token) config.headers.Authorization = `Bearer ${token}`;

    return config;
  },
  (error) => Promise.reject(error)
);

/**
 * RESPONSE INTERCEPTOR
 */
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Centralized error handling
    console.error("API Error:", error?.response || error);
    return Promise.reject(error);
  }
);

export default apiClient;
