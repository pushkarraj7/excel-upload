const BASE_API = "http://localhost:8060/api";

export const API_URLS = {
    UPLOAD_COMPANIES: `${BASE_API}/main/upload-companies`,
    UPLOAD_COMPANIES_PRICES: `${BASE_API}/main/bulk-upload-prices`,
    CALCULATE_AVERAGE: `${BASE_API}/main/calculate-average`,
    COMPANY_STATS: `${BASE_API}/main/company-stats`,
    INDEX_FILTER: `${BASE_API}/main/index-filter`,
};
